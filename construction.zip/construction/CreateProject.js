
import Animated, { Easing } from 'react-native-reanimated';
import React, { useState } from 'react';
import { View, StyleSheet, Text, TouchableOpacity, TextInput } from 'react-native';

export default function CreateProjectScreen() {
  const [projectName, setProjectName] = useState('');
  const [projectLocation, setProjectLocation] = useState('');
  const [projectDescription, setProjectDescription] = useState('');
  const [workingHours, setWorkingHours] = useState('');

  const handleCreateProject = () => {
    // Perform the create project action using the entered data
    console.log('Project Created');
    console.log('Name:', projectName);
    console.log('Location:', projectLocation);
    console.log('Description:', projectDescription);
    console.log('Working Hours:', workingHours);
    // Reset the fields
    setProjectName('');
    setProjectLocation('');
    setProjectDescription('');
    setWorkingHours('');
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Create Project</Text>
      <TextInput
        style={styles.input}
        placeholder="Name"
        value={projectName}
        onChangeText={setProjectName}
      />
      <TextInput
        style={styles.input}
        placeholder="Location"
        value={projectLocation}
        onChangeText={setProjectLocation}
      />
      <TextInput
        style={styles.input}
        placeholder="Description"
        value={projectDescription}
        onChangeText={setProjectDescription}
      />
      <TextInput
        style={styles.input}
        placeholder="Working Hours"
        value={workingHours}
        onChangeText={setWorkingHours}
      />
      <TouchableOpacity style={styles.createButton} onPress={handleCreateProject}>
        <Text style={styles.createButtonText}>Create</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#fff',
    padding: 20,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  input: {
    borderWidth: 1,
    borderColor: '#ccc',
    borderRadius: 5,
    padding: 10,
    marginBottom: 10,
    width: '100%',
  },
  createButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    marginTop: 10,
    width: '100%',
  },
  createButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
