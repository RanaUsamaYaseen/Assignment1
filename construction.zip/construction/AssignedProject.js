import React, { useState } from 'react';
import { View, StyleSheet, Text, TouchableOpacity } from 'react-native';

export default function AssignedProjectScreen() {
  const [selectedLabor, setSelectedLabor] = useState(null);
  const [assignedProject, setAssignedProject] = useState(null);

  // Simulated labor and project data
  const labors = [
    { id: 1, name: 'Labor 1' },
    { id: 2, name: 'Labor 2' },
    { id: 3, name: 'Labor 3' },
  ];
  const project = { id: 1, name: 'Project 1', description: 'Description 1' };

  const handleAssignProject = (labor) => {
    setSelectedLabor(labor);
    setAssignedProject(project);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Assigned Project</Text>
      {assignedProject ? (
        <View style={styles.projectContainer}>
          <Text style={styles.projectName}>{assignedProject.name}</Text>
          <Text style={styles.projectDescription}>{assignedProject.description}</Text>
        </View>
      ) : (
        <Text>No project assigned</Text>
      )}

      <Text style={styles.title}>Select Labor</Text>
      {labors.map((labor) => (
        <TouchableOpacity
          key={labor.id}
          style={styles.laborButton}
          onPress={() => handleAssignProject(labor)}
        >
          <Text style={styles.laborButtonText}>{labor.name}</Text>
        </TouchableOpacity>
      ))}
      {selectedLabor && (
        <Text style={styles.selectedLaborText}>Selected Labor: {selectedLabor.name}</Text>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
  },
  projectContainer: {
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#ccc',
    padding: 16,
    borderRadius: 8,
  },
  projectName: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 8,
  },
  projectDescription: {
    fontSize: 14,
  },
  laborButton: {
    marginBottom: 8,
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 8,
  },
  laborButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  selectedLaborText: {
    marginTop: 16,
    fontSize: 16,
    fontWeight: 'bold',
  },
});
