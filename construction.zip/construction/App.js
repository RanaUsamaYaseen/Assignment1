import React, { useState } from 'react';
import { View, StyleSheet } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import mainlogin from './mainlogin';
import AdminLoginScreen from './AdminLoginScreen';
import LabourRLoginScreen from './LabouRLoginScreen';
import AdminDashboardScreen from './AdminDashboardScreen';
import LabourDashboardScreen from './LabourDashboardScreen';
import CreateProject from './CreateProject';
import AssignedProject from './AssignedProject';
import HoursApproval from './HoursApproval';
import ManageLabour from './ManageLabour';
import Projects from './Projects';
import SeeLabourList from './SeeLabourList';
const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="MLogin" component={mainlogin} />
        <Stack.Screen name="AdminLoginScreen" component={AdminLoginScreen} />
        <Stack.Screen name="LabourLoginScreen" component={LabourRLoginScreen} />
        <Stack.Screen name="AdminDashboardScreen" component={AdminDashboardScreen} />
        <Stack.Screen name="LabourDashboardScreen" component={LabourDashboardScreen} />
        <Stack.Screen name="CreateProject" component={CreateProject} />
         <Stack.Screen name="AssignedProject" component={AssignedProject} />
        <Stack.Screen name="HoursApproval" component={HoursApproval} />
        <Stack.Screen name="ManageLabour" component={ManageLabour} />
        <Stack.Screen name="Projects" component={Projects} />
        <Stack.Screen name="SeeLabourList" component={SeeLabourList} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
