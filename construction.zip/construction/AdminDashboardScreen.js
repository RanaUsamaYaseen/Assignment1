import React from 'react';
import { View, StyleSheet, Text, TouchableOpacity, ImageBackground } from 'react-native';
import { useNavigation } from '@react-navigation/native';

import backgroundImage from './assets/background.jpg';

export default function DashboardScreen({ handleLogout }) {
  const navigation = useNavigation();

  const handleCreateProject = () => {
    navigation.navigate('CreateProject');
  };
   const handleAssignedProject = () => {
    navigation.navigate('AssignedProject');
  };
   const handleHoursApproval = () => {
    navigation.navigate('HoursApproval');
  };
   const handleProjects = () => {
    navigation.navigate('Projects');
  };
   const handleManageLabour = () => {
    navigation.navigate('ManageLabour');
  };
   const handleSeeLabourList = () => {
    navigation.navigate('SeeLabourList');
  };

  return (
    <View style={styles.container}>
      <ImageBackground source={backgroundImage} style={styles.backgroundImage}>
        <Text style={styles.dashboardTitle}>Admin Dashboard</Text>
        <TouchableOpacity style={styles.createProjectButton} onPress={handleCreateProject}>
          <Text style={styles.createProjectButtonText}>Create Project</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.createProjectButton} onPress={handleAssignedProject}>
          <Text style={styles.createProjectButtonText}>Assigned Project</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.createProjectButton} onPress={handleHoursApproval}>
          <Text style={styles.createProjectButtonText}>Hours Approval</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.createProjectButton} onPress={handleProjects}>
          <Text style={styles.createProjectButtonText}>Projects</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.createProjectButton} onPress={handleManageLabour}>
          <Text style={styles.createProjectButtonText}>Manage Labour</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.createProjectButton} onPress={handleSeeLabourList}>
          <Text style={styles.createProjectButtonText}>See Labour List</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.logoutButton} onPress={handleLogout}>
          <Text style={styles.logoutButtonText}>Logout</Text>
        </TouchableOpacity>
      </ImageBackground>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  backgroundImage: {
    flex: 1,
    resizeMode: 'cover',
    justifyContent: 'center',
    alignItems: 'center',
  },
  dashboardTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: '#fff',
  },
  createProjectButton: {
    backgroundColor: '#007bff',
    padding: 10,
    borderRadius: 5,
    marginBottom: 10,
  },
  createProjectButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logoutButton: {
    backgroundColor: '#dc3545',
    padding: 10,
    borderRadius: 5,
  },
  logoutButtonText: {
    color: '#fff',
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
});
